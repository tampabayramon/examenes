tr='<tr>';
td1='<td style="border-style: none; border-width: medium" valign="top" bgcolor="#000080">';
td2='<td style="border-style: none; border-width: medium" valign="top" bgcolor="#008000">';
p='<p align="center" style="margin-top: 5; margin-bottom: 5"> <font face="Arial" size="1" color="#FFFFFF">';
pe='</font>';
tde='</TD>';
tre='</TR>';
tds1=pe+tde+td1+p;
tds2=pe+tde+td2+p;

function dumpFormCollection() {
	document.write(tr);
	document.write(td1+p+"This document contains: " + document.forms.length + " forms." + tds1 + "Referrer (URL this page came from): " + "<B><BR>" + document.referrer +"</B>" + tds1 +" This URL:<B><BR>" + document.URL +"</B>" + tds1 + " Anchors: " + document.anchors.length+ tds1 + " Links: " + document.links.length + tds1 + " Images: " + document.images.length);
	document.write(pe+tde);
	document.write(tre);
}

function dumpFormObjects() {
	if (document.forms.length > 0) {
		for (var x=0; x< document.forms.length; x++) {
			document.write(tr);
			document.write(td2+p+"Form " + x + "<BR><B>" + document.forms[x].name + "</B>" + tds2 + " Id: <B>" + document.forms[x].id + "</B>" + tds2);
			document.write("Form Elements: <B>" + document.forms[x].length + "</B>" + tds2 + " Action to execute: <B><BR>" + document.forms[x].action +"</B>");
			document.write(pe+tde);
			document.write(tre);
			var elementsArray = document.forms[x].elements;		
			dumpFormElements(elementsArray);
		}
	}
}

function dumpFormElements(elementsArray) {
	if (elementsArray != null) {
		for(var i=0; (i < elementsArray.length); i++)  {
			document.write(tr);
			element = elementsArray[i];
			//document.write(td1+'&nbsp;'+tds1);
			document.write(td1+p+"<B>" + element.name+"</B>" + tds1);
			document.write("<B> Id:</B>" + element.id + tds1);
			document.write("<B> type:</B>" + element.type +tds1);
			if (element.length > 0 || element.value != "") {
				document.write("<B> value:</B>" + element.value + tds1);
			}
			if (element.maxLength != null) {
				document.write("<B> maxLength:</B>" + element.maxLength + tds1);
			}
			if (element.size != null) {
				document.write("<B> size:</B>" + element.size + tds1);
			}
			if (element.type == 'select-one' || element.type == 'select-multiple') {
				document.write("<B> Select Options:</B>" + element.length);
			}
			
			document.write(pe+tde);
			document.write(tre);
		}
	}
}


function dumpAnchorCollection() {
	document.write(tr);
	document.write(td1+p+" Anchors: " + document.anchors.length);
	document.write(pe+tde);
	document.write(tre);
}

function dumpAnchorObjects() {
	if (document.anchors.length > 0) {
		for (var x=0; x< document.anchors.length; x++) {
			document.write(tr);
			document.write(td2+p+"Anchor " + x + " name is: <B>" + document.anchors[x].name + "</B>" + tds2 + " Id: <B>" + document.anchors[x].id + "</B>" + tds2);
			document.write(" HREF to execute: <B><BR>" + document.anchors[x].href + tds2 + " HREF Text: " + document.anchors[x].innerHTML + "</B>");
			document.write(pe+tde);
			document.write(tre);
		}
	}
}