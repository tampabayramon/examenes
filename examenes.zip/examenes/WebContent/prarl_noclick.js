
var msg = "Copyright(c) 2004 Puerto Rico Amateur Radio League."
if(document.layers) window.captureEvents(Event.MOUSEDOWN);

function no_click(e){
if (navigator.appName == 'Netscape' && ( e.which == 2 || e.which == 3))
 {
  alert(msg);return false;
 }
 if (navigator.appName == 'Microsoft Internet Explorer' && (event.button == 2 || event.button == 3))
 {
   alert(msg);return false;
 }
}
window.onmousedown=no_click;
document.onmousedown=no_click;
