function submitSelectExam()
{

	var x=document.getElementsByName("startExamName");
	var isChecked=false;
	if (x != null) {	
		for (var i=0; i < x.length; i++ ) {
			if (x[i].checked) {
				isChecked=true;
			}
		}
	}
	
	if (isChecked == true) {
    	document.forms['questionForm'].submit();
    } else {
    	alert("Debe seleccionar un examen!");
    }
    return;
}
