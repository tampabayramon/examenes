function submitQuestion(theValue)
{
      document.questionForm.func.value = theValue;
      document.forms['questionForm'].submit();
}