

      function AjaxTimeoutTimer(strLength){

        //Set all of the defaults   
        this.loaded = false;
        this.intHeight = 600;
        this.intDivHeight = 150;
        this.objDiv = null;
        this.objIFr = null;
        this.top = 0;
        this.sessionLength = 1000*60*20;
        if(typeof(strLength)!="undefined")this.sessionLength = strLength;
        var timerWarn = window.setTimeout(loadMessage,this.sessionLength);
        this.maxWait = 1000*60*5;
        this.title = "Notificacion de Tiempo";
        this.message = "Ya lleva 15 minutos sin hacer nada. " + 
                       "Proceda a continuar con tomar el examen, " + 
                       "o visitar las paginas de Punto Fijo." + 
                       "Oprima para <span style='color:green'>Confirmar</span> " +
                       "su sesion.";
        this.confirm = "Confirmar";
        this.ignore = "Ignorar";
        this.extendedMessage = "Su sesion de examenes ya expiro!. " +
                               "Oprima <span style='color:green'>Confirmar</span> " +
                               "para verificar.."
        var ref = this;
        
        //determine browser height and height of div
        function calcBrowserSize(){
          if(self.innerHeight){
	        ref.intHeight = self.innerHeight;
            ref.intDivHeight = ref.objDiv.scrollHeight;
          }
          else if(document.documentElement && document.documentElement.clientHeight){
	        ref.intHeight = document.documentElement.clientHeight;
            ref.intDivHeight = ref.objDiv.clientHeight;
          }
          else if(document.body){
	        ref.intHeight = document.body.clientHeight;
            ref.intDivHeight = ref.objDiv.clientHeight;
          }
          ref.intHeight = parseInt(ref.intHeight);
          ref.intDivHeight = parseInt(ref.intDivHeight);
        }


        //Start to display message on scroll
        function loadMessage(){
        
          if(ref.loaded == false)ref.loaded = createAjaxConfirm();        
          //set reference
          ref.objDiv = document.getElementById("divAjaxTimer");
          ref.objIFr = document.getElementById("ifAjaxTimer");
          
          //position block off screen and show it
          ref.objDiv.style.top = "-1000px";
          ref.objIFr.style.top = "-1000px";
          ref.objDiv.style.display = "block";
          ref.objIFr.style.display = "block";
          if(navigator.userAgent.toLowerCase().indexOf("opera") != -1)ref.objIFr.style.visibility = "hidden";
          
          //Set all of the elements text
		  document.getElementById("divAjaxBut").style.display = "block";
		  document.getElementById("divAjaxContent").innerHTML = ref.message;
		  document.getElementById("divAjaxTitle").innerHTML = ref.title;
		  document.getElementById("ajaxB1").value = ref.confirm;
		  document.getElementById("ajaxB2").value = ref.ignore;
		  
		  //position block to top edge of screen
          calcBrowserSize();
          ref.objDiv.style.top = -ref.intDivHeight + "px";
          ref.objIFr.style.top = -ref.intDivHeight + "px";
          
          //prepare block to be scrolled in
          ref.top = -ref.intDivHeight;
          timerScroll = window.setInterval(scrollIn,1);
            timerWait = window.setTimeout(extendedWait,ref.maxWait);
        }

        //Determine how much user scrolled page down
        function GetScroll(){    
          var scrollY = document.documentElement.scrollTop;
          if(!scrollY)scrollY = document.body.scrollTop;            
          if(!scrollY)scrollY = window.pageYOffset;               
          if(!scrollY)scrollY = 0;
          return scrollY;
        }
        
        //some local(private) varaibles
        var timerScroll = null;
        var timerReject = null;
        var intStep = 2;
        var intStop = Math.floor(ref.intHeight/5);
    	var timerUpdate = null;
		var intDotCount = 0;
		var timerWait = null;

        //Function moves confirmation window into view
        function scrollIn(){
          if(parseInt(intStep) + parseInt(ref.top) <= parseInt(intStop) ){
            ref.top += intStep;
            var intT = ref.top + GetScroll();;
			ref.objDiv.style.top =  intT + "px";
			ref.objIFr.style.top =  intT + "px";
          }
          else{
             var cancel = window.clearInterval(timerScroll);
             ref.objDiv.style.top = GetScroll() + intStop + "px";
             ref.objIFr.style.top = ref.objDiv.style.top;
          }
        }
        
        //Confirm button pressed, make request, hide buttons, start annimation
		this.confirmTimer = function(){
          timerUpdate = window.setInterval(updateMessage,250);
          document.getElementById("divAjaxBut").style.display = "none";
          makeDWRRequest();
		}

        //Hide information if the ignore button was clicked
		this.ignoreTimer = function(){
          ref.objDiv.style.display = "none";
          ref.objIFr.style.display = "none";
          window.location = ajaxTimer.logoutURL;
		}

        //Annimate the request waiting time so it looks fancy
		function updateMessage(){
		  var strDotsMessage = "Updating Session.";
		  for(x=0;x<intDotCount;x++)strDotsMessage+=".";
		  document.getElementById("divAjaxContent").innerHTML = strDotsMessage;
		  intDotCount++;
		  if(intDotCount>4)intDotCount = 0;
		}
		
		//change message from normal to extended info
		function extendedWait(){
		  document.getElementById("divAjaxContent").innerHTML = ref.extendedMessage;
		  //force a page reload to see if login page shows up
		  document.location.href = document.location.href;
		}
	
        //Function Prepares calls xmlHttpRequest
        function makeDWRRequest(){

          //create reg exp so we do not grabbed cached material
          var regEx = /(\s|:)/gi;
          var strDT = "ts=" + new Date().toString().replace(regEx,"");                              
          
          //Make the request to the server
          //var loader1 = new net.ContentLoader(ref.serverURL,finishRequest,null,"POST",strDT); //Make request
          validateSession.getSessionValidateUser(finishRequest);        
        }
		
        //Function takes XML document 
        function finishRequest(reqXML){
          timerWarn = window.setTimeout(loadMessage,ref.sessionLength);
          var bx = window.clearTimeout(timerUpdate);
          //var strDoc = this.req.responseText;  //Grab HTML
          if(reqXML.indexOf("Session Updated - Server Time:") == 0){
            document.getElementById("divAjaxContent").innerHTML = "Puede continuar con el examen!";
            var timerHide = window.setTimeout(hideDiv,2000);
          }
          else{
            document.getElementById("divAjaxContent").innerHTML = "Ya termino esta sesion del examen!";
            var timerHide = window.setTimeout(hideDiv,3000);
            window.location = ajaxTimer.logoutURL;
          }
        }
        
        function createAjaxConfirm(){
          var ifr = document.createElement("iframe");
      
          var div1 = document.createElement("div");
          var div2 = document.createElement("div");
          var div3 = document.createElement("div");
          var div4 = document.createElement("div");
      
          var btn1 = document.createElement("input");
          var btn2 = document.createElement("input");
      
          ifr.id = "ifAjaxTimer";
          div1.id = "divAjaxTimer";
          div2.id = "divAjaxTitle";
          div3.id = "divAjaxContent";
          div4.id = "divAjaxBut"; 
      
          btn1.type="button";
          btn2.type="button";
          btn1.id = "ajaxB1";
          btn2.id = "ajaxB2";
          btn1.className = "confirm";
          btn2.className = "ignore";
          btn1.onclick = function(){ajaxTimer.confirmTimer();return false;}
          btn2.onclick = function(){ajaxTimer.ignoreTimer();return false;}
          btn1.value = "text";
          btn2.value = "text";     
     
          div1.appendChild(div2);   
          div1.appendChild(div3);
          div4.appendChild(btn1);
          div4.appendChild(btn2);
          div1.appendChild(div4); 

          document.forms[0].appendChild(ifr);
          document.forms[0].appendChild(div1);
            
          return  true;
        }
        
        //Hide div and iframe
        function hideDiv(){
          ref.objDiv.style.display = "none";
          ref.objIFr.style.display = "none";
        }
        
      }
      
      function UpdateSessionMaxInactiveInterval(newTimer){
  		this.sessionMaxInactiveInterval = newTimer * 1000;
		sessionMaxInactiveInterval=this.sessionMaxInactiveInterval;
      	
  	  }
//=============================================
//Update information here for customization here!
//==============================================

      	var sessionMaxInactiveInterval=1000 * 60 * 10;
		validateSession.getSessionMaxInactiveInterval(UpdateSessionMaxInactiveInterval);
      	
      	//alert("New interval is ="+ sessionMaxInactiveInterval);
      	var ajaxTimer = new AjaxTimeoutTimer(sessionMaxInactiveInterval);
		ajaxTimer.maxWait = 1000 * 60 * 5;           //default time 5 minutes
		ajaxTimer.title = "Notificacion de Tiempo";
		//ajaxTimer.message = "Your current session is about to expire.";
		//ajaxTimer.confirm = "Update";
		ajaxTimer.ignore = "Terminar";
		ajaxTimer.logoutURL = '/examenes2007/index.jsp';
		ajaxTimer.extendedMessage = "Su sesion probablemente ya expiro!. "
      

  	  
