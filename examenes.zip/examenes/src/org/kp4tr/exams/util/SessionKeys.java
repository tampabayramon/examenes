package org.kp4tr.exams.util;

public final class SessionKeys {

	// public static final String DB = "DBConnectionBroker";

	public static final String LOG = "log4j";
	public static final String GENERAL = "G";
	public static final String TECHNICIAN = "T";
	public static final String EXTRA = "E";
	public static final String SESSIONLISTENER = "session.listener";
}
