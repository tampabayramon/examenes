package org.kp4tr.exams.layers;

import org.kp4tr.exams.delegate.IDelegate;

public abstract class AbstractDelegate implements IDelegate {

}
