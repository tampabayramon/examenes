package org.kp4tr.exams.layers;

public abstract class AbstractServiceRequest implements IServiceRequest {

	public AbstractServiceRequest() {
		super();

	}

}
