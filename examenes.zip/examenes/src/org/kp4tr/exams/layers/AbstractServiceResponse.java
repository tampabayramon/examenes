package org.kp4tr.exams.layers;

public abstract class AbstractServiceResponse implements IServiceResponse {

}
