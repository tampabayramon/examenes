package org.kp4tr.exams.layers;

public interface IServiceRequest {

}
