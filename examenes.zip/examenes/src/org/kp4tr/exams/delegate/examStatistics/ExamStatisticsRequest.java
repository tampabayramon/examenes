package org.kp4tr.exams.delegate.examStatistics;

import org.kp4tr.exams.layers.AbstractServiceRequest;

public class ExamStatisticsRequest extends AbstractServiceRequest {

}
